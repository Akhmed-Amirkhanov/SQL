-- Session #1
BEGIN;
SELECT sum(rating) FROM pizzeria;
-- Session #2
BEGIN;
INSERT INTO pizzeria VALUES (11, 'Kazan Pizza 2', 4);
COMMIT;
-- Session #1
SELECT sum(rating) FROM pizzeria;
COMMIT;
SELECT sum(rating) FROM pizzeria;
-- Session #2
SELECT sum(rating) FROM pizzeria;