create table cities (
    point1 varchar not null,
    point2 varchar not null,
    cost integer not null
);

insert into cities (point1, point2, cost) VALUES
('a', 'b', 10), ('b', 'a', 10),
('a', 'c', 15), ('c', 'a', 15),
('a', 'd', 20), ('d', 'a', 20),
('b', 'c', 35), ('c', 'b', 35),
('b', 'd', 25), ('d', 'b', 25),
('c', 'd', 30), ('d', 'c', 30);

with recursive paths as (
    select 
        point1 as start,
        point2 as next,
        cost,
        array[point1, point2]::varchar[] as route, 
        1 as visited
    from cities
    where point1 = 'a'
    
    union all
 
    select 
        p.start,
        c.point2,
        p.cost + c.cost,
        p.route || c.point2::varchar, 
        p.visited + 1
    from paths p
    join cities c on p.next = c.point1
    where not c.point2 = ANY(p.route) 
      and p.visited < 3  
),
all_tours as (
    select 
        p.cost + c.cost as total_cost,
        p.route || p.start::varchar as tour  
    from paths p
    join cities c on p.next = c.point1 and c.point2 = p.start
    where p.visited = 3 
)
select 
    total_cost,
    tour
from all_tours
where total_cost = (select MIN(total_cost) from all_tours)
order by total_cost, tour;