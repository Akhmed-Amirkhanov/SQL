-- Session #1
-- обновить рейтинг для "Pizza Hut" до 5 баллов в режиме транзакции
BEGIN;
UPDATE pizzeria
SET rating = 5
WHERE name = 'Pizza Hut';

-- проверить, что в сессии №1 ты видишь изменения
SELECT * FROM pizzeria;

-- Session #2
-- проверить, что в сессии №2 изменения ещё не видны
SELECT * FROM pizzeria;

-- Session #1
-- опубликовать изменения для всех параллельных сессий (зафиксировать транзакцию)
COMMIT;

-- Session #2
-- проверить, что теперь в сессии №2 изменения видны
SELECT * FROM pizzeria;